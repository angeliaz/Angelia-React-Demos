1.

>A container does data fetching and then renders its corresponding sub-component. That’s it.



2.[Smart and Dumb Components](https://medium.com/@dan_abramov/smart-and-dumb-components-7ca2f9a7c7d0)


https://github.com/Lucifier129/Lucifier129.github.io/issues

http://www.jianshu.com/p/3334467e4b32